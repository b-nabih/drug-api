package com.galaxe.drug;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
