package com.galaxe.drug.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="drug")

public class Drug {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="national_drug_code")
	private int nationalDrugCode;
	
	@Column(name="drug_name")
	private String drugName;
	
	@Column(name="drug_strength")
	private String drugStrength;
	
	@Column(name="generic_code_num")
	private int genericCodeNum;
	
	@Column(name="unit_of_measurement")
	private int unitOfMeasurement;
	
	@Column(name="dosage")
	private String dosage;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNationalDrugCode() {
		return nationalDrugCode;
	}

	public void setNationalDrugCode(int nationalDrugCode) {
		this.nationalDrugCode = nationalDrugCode;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public String getDrugStrength() {
		return drugStrength;
	}

	public void setDrugStrength(String drugStrength) {
		this.drugStrength = drugStrength;
	}

	public int getGenericCodeNum() {
		return genericCodeNum;
	}

	public void setGenericCodeNum(int genericCodeNum) {
		this.genericCodeNum = genericCodeNum;
	}

	public int getUnitOfMeasurement() {
		return unitOfMeasurement;
	}

	public void setUnitOfMeasurement(int unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}

	public String getDosage() {
		return dosage;
	}

	public void setDosage(String dosage) {
		this.dosage = dosage;
	}

}
