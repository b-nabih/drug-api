package com.galaxe.drug.service;

import java.util.List;

import com.galaxe.drug.model.Drug;

public interface DrugService {
	
	public Drug saveDrug(Drug drug);
	public List<Drug> saveDrugs(List<Drug> drugs);
	public List<Drug> getDrugs();
	public Drug getDrugById(int id);
	public Drug getDrugByNDC(int nationalDrugCode);
	public Drug getDrugByName(String name);
	public String deleteDrug(int id);
	public Drug updateDrug(Drug drug, int id);

}
