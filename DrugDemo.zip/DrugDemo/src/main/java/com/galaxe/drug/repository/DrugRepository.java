package com.galaxe.drug.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.galaxe.drug.model.Drug;

public interface DrugRepository extends JpaRepository<Drug,Integer>{
	
	@Query("select d from Drug d where d.nationalDrugCode = :nationalDrugCode")
	Drug findByNDC(@Param("nationalDrugCode") int nationalDrugCode);
	
	@Query("select d from Drug d where d.drugName = :drugName")
	Drug findByName(@Param("drugName") String drugName);
	
}
