package com.galaxe.drug.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.galaxe.drug.model.Drug;
import com.galaxe.drug.service.DrugServiceImpl;

@RestController
public class DrugController {
	
	@Autowired
	private DrugServiceImpl service;
	
	@PostMapping("/adddrug")
	public Drug addDrug(@RequestBody Drug drug) {
		return service.saveDrug(drug);
	}
	
	@PostMapping("/adddrugs")
	public List<Drug> addDrugs(@RequestBody List<Drug> drugs) {
		return service.saveDrugs(drugs);
	}
	
	@GetMapping("/drugs")
	public List<Drug> findAllDrugs() {
		return service.getDrugs();
	}
	
//	@GetMapping("/drug/{id}")
//	public Drug findDrugById(@PathVariable int id) {
//		return service.getDrugById(id);
//	}
	
	@GetMapping("/drug/{ndc}") // ndc = national drug code
	public Drug findByNDC(@PathVariable int ndc) {
		return service.getDrugByNDC(ndc);
	}
	
	@GetMapping("/drugname/{name}")
	public Drug findDrugByName(@PathVariable String name) {
		return service.getDrugByName(name);
	}
	
	@PutMapping("/update/{id}")
	public Drug updateDrug(@PathVariable int id, @RequestBody Drug drug) {
		return service.updateDrug(drug, id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteDrug(@PathVariable int id) {
		return service.deleteDrug(id);
	}

}
