package com.galaxe.drug.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.galaxe.drug.model.Drug;
import com.galaxe.drug.repository.DrugRepository;

@Service
public class DrugServiceImpl implements DrugService{
	
	@Autowired
	private DrugRepository repo;
	
	@Autowired
	SessionFactory sf;

	@Override
	public Drug saveDrug(Drug drug) {		
		return repo.save(drug);
	}

	@Override
	public List<Drug> saveDrugs(List<Drug> drugs) {
		return repo.saveAll(drugs);
	}

	@Override
	public List<Drug> getDrugs() {
		return repo.findAll();
	}

	@Override
	public Drug getDrugById(int id) {
		return repo.findById(id).orElse(null);
	}
	
	@Override
	public Drug getDrugByNDC(int nationalDrugCode) {
		return repo.findByNDC(nationalDrugCode);
	}

	@Override
	public Drug getDrugByName(String name) {
		return repo.findByName(name);
	}

	@Override
	public String deleteDrug(int id) {
		repo.deleteById(id);
		return "Drug removed: " + id;
	}

	@Override
	public Drug updateDrug(Drug drug, int id) {
		Drug existingDrug = repo.findById(id).orElse(null);
		existingDrug.setDrugName(drug.getDrugName());
		existingDrug.setDosage(drug.getDosage());
		existingDrug.setUnitOfMeasurement(drug.getUnitOfMeasurement());
		return repo.save(existingDrug);
	}

}
